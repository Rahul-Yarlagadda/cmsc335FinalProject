Submitted by: Rahul Yarlagadda (directory id: ryarlag1)
Group Members: Rahul Yarlagadda (directory id: ryarlag1), Sujithkumar Manoharan (directory id: sujith26), Dave Jose (directory id: djose)
            App Description: Soundstream is an online music website you can utilize to create an online music profile 
            where you can create a music library to log your favorite songs, artist, and genre.
            YouTube Video Link: 
            APIs: SpotifyAPI (https://developer.spotify.com/documentation/web-api)
            Contact Email:  ryarlag1@terpmail.umd.edu